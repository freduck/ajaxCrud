 <!DOCTYPE html>
                  <html lang="en">
                  <head>
                     <meta charset="UTF-8">
                     <meta name="viewport" content="width=device-width, initial-scale=1.0">
                     <title>Document</title>
					 
					 <link rel="stylesheet" href="bootstrap.min.css">
                  </head>
                  <body>
				  <div class="container">
				  <div class="col-md-8 m-auto" style="margin-left:20%;;">
				  <div class="card-header bg-success text-center text-white" style="height:50px;">Add Data</div>
				  <div class="alert alert-success text-center text-white h4 mt-3" id="result" style="display:none;">
				  
				  </div>
                     
					 <div class="">
					 <label>Email</label>
					 <input type="email" name="email" class="form-control" required id="email">
					 <input type="hidden" name="id" class="form-control" required id="id">
					 </div>
					 
					 <div class="form-group">
					 <label>Password</label>
					 <input type="password" name="password" class="form-control" required id="password">
					 </div>
					 <div class="form-group">
					 <button class="btn btn-success col-12" id="button">Save Data</button>
					 <button class="btn btn-success col-12" id="update" style="display:none;">Update Data</button>
					 </div>
					<div class="form-group">
					<?php include("all.php");?>
					</div>
					 </div>
					 </div>
					 <script src="js/jquery.min.js"></script>
					 <script>
					
						 $("#button").on("click",function(){
							 var email=$("#email").val();
							 var password= $("#password").val();
						var c = console.log.bind(document);
					$.ajax({
						url:"add_data.php",
						type:"POST",
						dataType:"text",
						data:"email="+email +"&password="+password,
						success:function(r){
							$("#result").show();
							$("#result").html(r+ "!!!");
							setTimeout(function(){
								location.reload();
							},3000);
						}
					});
						 });
					$(document).delegate("#edit","click",function(){
						 var id = $(this).attr("data-id");
						 $.ajax({
							 url:"edit.php",
							 type:"POST",
							 data:"id="+id,
							 success:function(resp){
								 response = JSON.parse(resp);
								 $("#email").val(response.email);
								 $("#password").val(response.password);
								 $("#id").val(response.id);
								 $("#button").hide();
								 $("#update").show();
								 
							 }
						 });
						
					});
					$("#update").on("click",function(){
							 var id=$("#id").val();
							 var password= $("#password").val();
						var c = console.log.bind(document);
					$.ajax({
						url:"update.php",
						type:"POST",
						dataType:"text",
						data:"id="+id+"&email="+$("#email").val() +"&password="+$("#password").val(),
						success:function(r){
							
						
							$("#result").show();
							$("#result").html(r + "!!!");
							setTimeout(function(){
								location.reload();
							},3000);
						}
					});
						 });
						 $(document).delegate("#delete","click",function() {
        
        var id = $(this).attr("data-id");
        $.ajax({
            type: "POST",
            url: "delete.php",
            data: "id=" + id,
            success: function(result) {
            $("#result").show();    
            $("#result").html(result);
			setTimeout(()=>{
				location.reload();
			},2000);
            }
            
        })
        
    });
					 </script>
                  </body>
                  </html>