
<?php
$connection=mysqli_connect("localhost","root","","add");
$total_records_per_page = 5;
  
  
    //determine the total number of pages available  
	if (isset($_GET['page']) && $_GET['page']!="") {
    $page = $_GET['page'];
    } else {
        $page = 1;
        }
	$offset = ($page-1) * $total_records_per_page;
$previous_page = $page - 1;
$next_page = $page + 1;
$adjacents = "2";
$result_count = mysqli_query(
$connection,
"SELECT COUNT(*) As total_records FROM `users`"
);
$total_records = mysqli_fetch_array($result_count);
$total_records = $total_records['total_records'];
$total_no_of_pages = ceil($total_records / $total_records_per_page);
$second_last = $total_no_of_pages - 1;
$result=mysqli_query($connection,"select * from users LIMIT $offset, $total_records_per_page");

$res=mysqli_query($connection,"select * from users");
$r=mysqli_fetch_assoc($res);
echo "<table border='1' class='table'>
<tr>
<td align=center> <b>Roll No</b></td>
<td align=center><b>Email</b></td>
<td align=center><b>Password</b></td>
<td align=center><b>Action</b></td>
</tr>";

while($data = mysqli_fetch_assoc($result))
{   ?>
    <tr>
    <td align=center><?php echo $data['id'];?></td>
    <td align=center><?php echo $data['email'];?></td>
    <td align=center><?php echo $data['password'];?></td>
     <td align=center><button data-id="<?php echo $data['id'];?>" id="edit" class="btn btn-success">Edit</button><button data-id="<?php echo $data['id'];?>" id="delete" class="btn btn-danger" style="margin-left:20px;">Delete</button></td>
	 
    </tr>
	<?php
}
?>
</table>
    

<ul class="pagination">

    
<li <?php if($page <= 1){ echo "class='disabled'"; } ?>>
<a class='page-link' <?php if($page > 1){
echo "href='?page=$previous_page'";

} ?>>Previous</a>
</li>
    <?php
	if ($total_no_of_pages <= 10){  	 
	for ($counter = 1; $counter <= $total_no_of_pages; $counter++){
	if ($counter == $page) {
	echo "<li class='active page-item'><a class='page-link'>$counter</a></li>";	
	        }else{
        echo "<li><a href='?page=$counter' class='page-link'>$counter</a></li>";
                }
        }
}
	
	
	?>
<li <?php if($page >= $total_no_of_pages){
echo "class='disabled'";
} ?>>
<a <?php if($page < $total_no_of_pages) {
echo "href='?page=$next_page'";
} ?> class='page-link'>Next</a>
</li>

<?php if($page < $total_no_of_pages){
echo "<li><a href='?page=$total_no_of_pages' class='page-link'>Last &rsaquo;&rsaquo;</a></li>";
} ?>
</ul>
