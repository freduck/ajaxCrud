<?php

$connection=mysqli_connect("localhost","root","","add");
$id=$_POST['id'];
$email=$_POST['email'];
$password=$_POST['password'];
$sql=mysqli_query($connection,"UPDATE users SET email='$email', password='$password' WHERE id='$id'");
if($sql){
	$result="Record Has Been Updated";
	echo $result;
}
//echo json_encode($result);
?>