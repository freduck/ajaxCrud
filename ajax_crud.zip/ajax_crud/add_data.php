<?php
$connection=mysqli_connect("localhost","root","","add");
$email=$_POST['email'];
$password=$_POST['password'];
if(empty($email) || empty($password)){
	echo "please Fill out all fields ";
	exit();
}else{

$sql=mysqli_query($connection,"INSERT INTO users (email,password) VALUES ('$email','$password')");
if($sql){
	echo "Record Added";
}else{
echo "2";	
}
}


?>