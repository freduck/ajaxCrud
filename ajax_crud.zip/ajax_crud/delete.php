<?php

$connection=mysqli_connect("localhost","root","","add");
$id=$_POST['id'];
$sql=mysqli_query($connection,"DELETE FROM users WHERE id='$id'");
if($sql){
	echo "Record Has Been Deleted";
}

?>