<?php

$connection=mysqli_connect("localhost","root","","add");
$id=$_POST['id'];
$sql=mysqli_query($connection,"SELECT * FROM users WHERE id='$id'");
if(mysqli_num_rows($sql)>0){
	$row=mysqli_fetch_assoc($sql);
	$result=[];
	$result['id']=$row['id'];
	$result['email']=$row['email'];
	$result['password']=$row['password'];
	//echo $result['email'];
}
echo json_encode($result);
?>